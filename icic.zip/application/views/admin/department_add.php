<section class="content">
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn" href="http://localhost/icic/Department">View Department</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Add Departments</h3>
                        <div class="msg" style="color:red;">
                        </div>
                    </div><!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <form action="http://localhost/icic/Department/add" method="post">
                            <table class="table table-hover">
                                <tbody><tr>
                                        <td>Department Name</td><td><input type="text" name="department_name" required=""></td>
                                    </tr>
                                    <tr>
                                        <td>Location</td>
                                        <td>
                                            <select name="location">
                                                <option value="">Select Location</option>
                                                <option value="C001">amania</option>
                                                <option value="C008">sweedan</option>
                                            </select>
                                            <button type="button" class="btn btn-default btn-sm model-trigger" data-controller="Location/add" data-xtoggle="modal" data-xtarget="#myModal">Add Location</button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td></td><td><input type="submit" name="submit" value="SAVE"></td>
                                    </tr>
                                    <tr>
                                        <td></td><td>
                                            <div class="msg" style="color:red;"></div></td>
                                    </tr>

                                </tbody></table>
                        </form>


                    </div><!-- /.box-body -->

                </div><!-- /.box -->
            </div>
        </div>
    </section>

</section>
