<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>User Page</title>
  </head>
  <body>
    <h2>User page</h2>
    <a href="<?php echo base_url('Login/logout') ?>">Log Out</a>
  </body>
</html>
