<?php

class Model_country extends MY_Model {

    protected $table_name = 'country';
    protected $primary_key = 'id';

}

?>