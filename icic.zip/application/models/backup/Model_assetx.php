<?php

class Model_assetx extends MY_Model {
    protected $table_name = 'assets';
    protected $primary_key = 'assets_id';
}

?>