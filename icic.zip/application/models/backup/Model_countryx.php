<?php

class Model_countryx extends MY_Model {
    protected $table_name = 'country';
    protected $primary_key = 'id';
    
    function test(){
        return 'hi';
    }
}

?>