<?php

class Model_locationx extends MY_Model {
    protected $table_name = 'locations';
    protected $primary_key = 'id';
    
    function test(){
        return 'hi';
    }
}

?>