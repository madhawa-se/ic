<?php

class Model_userx extends MY_Model {
    protected $table_name = 'users';
    protected $primary_key = 'user_id';
}

?>